<?php
namespace Mouf\NodeJsInstaller;

class NodeJsInstallerException extends \Exception
{
}
