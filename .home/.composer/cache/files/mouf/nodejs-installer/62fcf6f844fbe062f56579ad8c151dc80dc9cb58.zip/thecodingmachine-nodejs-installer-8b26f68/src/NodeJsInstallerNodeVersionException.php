<?php
namespace Mouf\NodeJsInstaller;

class NodeJsInstallerNodeVersionException extends NodeJsInstallerException
{
}
